CAP 4730 Assignment 2
Wilson Staley

This is modification of the Smooth program, that
rasterizes 3-D meshes.  It implements a z-buffer
algorithm as well as shading.

I compiled and ran the code on MacOS High Sierra 10.13.3
After installing FreeGLUT, I was able to compile and run
the program using the given make file.  I used the
following commands:

make
./smooth
